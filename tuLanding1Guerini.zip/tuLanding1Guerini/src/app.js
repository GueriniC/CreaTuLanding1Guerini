import NavBar from './components/navBar';
import Item from './components/item';

function App() {
  return (
    <div>
      <NavBar />
      <Item greeting="Bienvenido!" />
    </div>
  );
}

export default App;