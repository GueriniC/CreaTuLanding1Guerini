function Cart() {
    return (
      <div>
        <span>🛒</span>
        <span>0</span>
      </div>
    );
  }
  
  export default Cart;