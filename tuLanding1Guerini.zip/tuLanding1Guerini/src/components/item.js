function Item({ greeting }) {
    return (
      <div>
        <h2>{greeting}</h2>
      </div>
    );
  }
  
  export default Item;