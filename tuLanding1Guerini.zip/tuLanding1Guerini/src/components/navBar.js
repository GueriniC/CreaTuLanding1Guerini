import Cart from './cart';

function NavBar() {
  return (
    <nav>
      <h1>Compras Guerini</h1>
      <ul>
        <li>Inicio</li>
        <li>Productos</li>
        <li>Contacto</li>
      </ul>
      <Cart />
    </nav>
  );
}

export default NavBar;